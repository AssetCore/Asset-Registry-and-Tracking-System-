﻿namespace AssetRegistry.Api.Controllers
{
    public class LocationsController
    {
    }
}
