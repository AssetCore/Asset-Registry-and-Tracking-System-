﻿namespace AssetRegistry.Api.Controllers
{
    public class CategoriesController
    {
    }
}
