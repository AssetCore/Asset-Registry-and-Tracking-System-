﻿namespace AssetRegistry.Api.Mapping
{
    public class AssetMappings
    {

    }
}
