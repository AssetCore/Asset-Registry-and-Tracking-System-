﻿namespace AssetRegistry.Api.Contracts
{
    public class PagedResult
    {
    }
}
